module MultiSet (
    MSet,
    add,
    occs,
    elems,
    subeq,
    eq,
    union,
    empty
) where

-- Define the MSet type constructor.
data MSet a = MS [(a, Int)]
    deriving (Show)


-- Define a function to add an element to an MSet.
add :: Eq a => MSet a -> a -> MSet a
add (MS ms) v = MS $ add' ms v
  where
    add' [] v' = [(v', 1)]
    add' ((x, n):xs) v'
        | x == v' = (x, n+1) : xs
        | otherwise = (x, n) : add' xs v'

-- Define a function to get the number of occurrences of an element in an MSet.
occs :: Eq a => MSet a -> a -> Int
occs (MS ms) v = foldr (\(x, n) acc -> if x == v then n + acc else acc) 0 ms

-- Define a function to get a list of all elements in an MSet, ignoring multiplicities.
elems :: MSet a -> [a]
elems (MS ms) = map fst ms

-- Define a function to check if one MSet is a subset of another. (if each element in MSet1 is also in MSet2).
subeq :: Eq a => MSet a -> MSet a -> Bool
subeq (MS ms1) (MS ms2) = all (\(x, n) -> n <= occs (MS ms2) x) ms1

-- Define a function to check if two MSets are equal (with the same elements and multiplicities)
eq :: Eq a => MSet a -> MSet a -> Bool
eq ms1 ms2 = subeq ms1 ms2 && subeq ms2 ms1

-- Define a function to combine two MSets which is containing all the elements of mset1 and mset2, with the sum of the corresponding multiplicities.
union :: Eq a => MSet a -> MSet a -> MSet a
union mset1 mset2 = foldl add mset1 (elems mset2)

-- Define an empty MSet
empty :: MSet a
empty = MS []


-- Ensure that every MSet returned by a function is well-formed
add mset v = if wellFormed mset' then mset' else error "Result not well-formed"
    where mset' = add' mset v
occs mset v = if wellFormed mset then occs' mset v else error "Result not well-formed"
union mset1 mset2 = if wellFormed mset' then mset' else error "Result not well-formed"
    where mset' = union' mset1 mset2


-- Note:
{-
#The MSet type constructor is defined as a list of pairs of an element and its multiplicity. 
#The empty function returns an empty MSet as an empty list. 
#The add function takes an MSet and an element, and adds the element to the MSet with multiplicity 1 if it is not already in the MSet. 
#The occs function takes an MSet and an element, and returns the number of occurrences of the element in the MSet. 
#The elems function takes an MSet and returns a list of all the elements in the MSet (ignoring multiplicity).
#The subeq function takes two MSets and returns True if every element in the first MSet is also in the second MSet with at least the 
same multiplicity. 
#The eq function takes two MSets and returns True if they contain the same elements with the same multiplicities.
#The union function takes two MSets and returns an MSet with the elements and multiplicities of both MSets combined. 
#The wellFormed function is defined to check if an MSet is well-formed, and is used throughout the implementation to 
ensure that all returned MSets are well-formed.
-}