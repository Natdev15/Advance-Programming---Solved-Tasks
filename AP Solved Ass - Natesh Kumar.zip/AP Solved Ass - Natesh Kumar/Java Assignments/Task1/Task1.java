import java.util.Scanner;
public class Exe1 {

public static void main(String[] args) {
        //Initialize the Scanner object and necessary variables
        Scanner input = new Scanner(System.in);
        double sum = 0;
        int count = 0;

        System.out.print("Enter a number (or 0 to finish): ");
        double num = input.nextDouble();

        //Loop until the user inputs 0
        while (num != 0) {
            sum += num;
            count++;

            // Prompt the user to enter a number
            System.out.print("Enter a number (or 0 to finish): ");
            num = input.nextDouble();
        }

        //If the first number entered is 0, print "Empty sequence" and break out of the loop
        if (count == 0 && num == 0) {
            System.out.println("Empty sequence");
        } 
        //else if the count is greater than 0, calculate the average and print it
        else {
            double average = sum / count;
            System.out.println("Average of the sequence: " + average);
        }

        input.close();
    }
}
