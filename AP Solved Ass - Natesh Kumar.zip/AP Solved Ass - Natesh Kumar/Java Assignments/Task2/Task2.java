import java.util.Scanner;
public class Exe2 {

public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in);
        String[] strings = new String[10];
        
        //Loop through the array and ask the user to enter 10 strings
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter string n." + (i+1) + ": ");
            strings[i] = input.nextLine();
        }

        // Sorting Algorithm to sort the strings
        for (int i = 0; i < 9; i++) {
            for (int j = i + 1; j < 10; j++) {
                //If the prev: string is greater than the curr: string, swap them
                if (strings[i].compareTo(strings[j]) > 0) {
                    String temp = strings[i];
                    strings[i] = strings[j];
                    strings[j] = temp;
                }
            }
        }
        //Printing the sorted strings
        System.out.println("Sorted Strings:");
        for (String s : strings) {
            System.out.println(s);
        }

        input.close();
    }
}
