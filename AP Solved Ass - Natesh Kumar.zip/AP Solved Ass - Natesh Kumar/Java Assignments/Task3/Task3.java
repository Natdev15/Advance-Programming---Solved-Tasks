
public abstract class Time implements Comparable<Time> {

    public abstract int getHH(); //It will return the hours (an integer from 0 to 23)

    public abstract int getMM(); //It will return the minutes (an integer from 0 to 59)

    public boolean equals(Object o) {
        if (o instanceof Time) {
            Time t = (Time) o;
            return this.getHH() == t.getHH() && this.getMM() == t.getMM();
        }
        return false;
    }

    public int compareTo(Time t) {
        if (this.getHH() < t.getHH()) {
            return -1;
        } else if (this.getHH() > t.getHH()) {
            return 1;
        }
             else {
                return 0;
            }
    }
}

// This abstract class represents the hours of a day and includes the methods getHH() which returns the hours (an integer from 0 to 23), 
// getMM() which returns the minutes (an integer from 0 to 59), and equals(Object o) which returns true only if o and this are the same time. 


// The class also implements the Comparable interface and the compareTo(Object o) method according to the specification described in the 
// documentation of java.util.Comparable. The compareTo() method compares two Time objects based on their hours and minutes, returning a negative integer, 
// zero, or a positive integer if this object is less than, equal to, or greater than the specified object t.
