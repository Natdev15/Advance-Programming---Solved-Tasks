import time

def benchmark(iter=1, verbose=False):
    #definie the decorator func that takes in the function to be decorated as an argument. 
    def decorator(func): 

        #define the wrapper func that will replace the original function.
        def wrapper(*args, **kwargs): 

            #Initialize an empty dictionary where it will store the execution times if verbose will be 'True'
            result = {}     
            result["fun-name"] = func.__name__
            result["args"] = args
            result["iter"] = iter
            #Initialize an empty list to store the execution times
            times = []      
            for i in range(iter):
                # Get the start time
                start_time = time.perf_counter()
                #call the original function with the given arguments. 
                #(*args: if it will be in the form of Tuple () and **kwargs: if it will be in the form of Dict {}) 
                func(*args, **kwargs)
                #get the end time and calculate the exec: time
                end_time = time.perf_counter()
                #append the execution time to the list
                times.append(end_time - start_time)
            #calculate the average execution time    
            avg_time = sum(times) / len(times)
            result["average"] = avg_time
            if verbose:
                for i, t in enumerate(times):
                    result[i] = t

            #return the result in the form of dictionary        
            return result
        
        #return the wrapper()
        return wrapper
    #return the decorator()
    return decorator

#Note: 
"""The benchmark decorator: takes two optional parameters: iter and verbose. 
iter specifies the number of times the decorated function should be executed, and 
verbose specifies whether to return the execution times of each invocation or just the average execution time. 
By default, iter is set to 1 and verbose is set to False."""

"""The decorator function itself is defined inside the benchmark function. It takes in the function to be decorated as an argument and returns a wrapper function 
that replaces the original func. The wrapper function uses a for loop to execute the original function the specified number of times and calculate 
the execution time for each invocation. It then calculates the average execution time and returns a dictionary containing the function name, arguments, number of 
iterations, and either the average execution time or the execution times for each invocation (depending on the value of verbose)."""