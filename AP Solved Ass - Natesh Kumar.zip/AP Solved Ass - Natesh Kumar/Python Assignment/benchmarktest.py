import benchmark

def fib(n): #recursive definition of fibonacci function
	if (n == 0) or (n == 1):
		return n
	return fib(n - 1) + fib(n - 2)

#To use the decorator, simply add the @benchmark decorator before the function definition and 
#specify the desired values for iter and verbose

@benchmark.benchmark(iter=10, verbose = True) #decorate myFib
def myFib(n):
	fib(n)

#this code is executed typing "python3 testBenchmark.py" in a shell
if __name__ == "__main__":
	print(myFib(30))
